"use client";

export default function ControlsPanel({ onReset }) {
  return (
    <>
      <button
        onClick={onReset}
        className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400 transition"
      >
        Reset Design
      </button>
    </>
  );
}
