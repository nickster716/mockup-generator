'use client';

export default function ImageSelector({ images, onSelect, selected }) {
  return (
    <div className="flex gap-2 overflow-x-auto">
      {images.map((img, idx) => (
        <img
          key={idx}
          src={img}
          alt={`Product ${idx}`}
          onClick={() => onSelect(img)}
          className={`h-24 cursor-pointer border-2 rounded ${selected === img ? 'border-blue-500' : 'border-transparent'}`}
        />
      ))}
    </div>
  );
}
