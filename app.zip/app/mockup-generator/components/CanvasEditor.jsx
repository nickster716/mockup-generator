"use client";

import { Rnd } from "react-rnd";
import { useState, useRef, useEffect } from "react";
import { toPng } from "html-to-image";

export default function CanvasEditor({
  baseImage,
  designImage,
  onRemoveDesign,
}) {
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [size, setSize] = useState({ width: 150, height: 150 });
  const [selected, setSelected] = useState(false);
  const canvasRef = useRef(null);

  // Reset position & size on new designImage
  useEffect(() => {
    if (designImage) {
      setPosition({ x: 100, y: 100 });
      setSize({ width: 150, height: 150 });
    }
  }, [designImage]);

  const handleDownload = () => {
    if (!canvasRef.current) return;
    toPng(canvasRef.current)
      .then((dataUrl) => {
        const link = document.createElement("a");
        link.download = "mockup.png";
        link.href = dataUrl;
        link.click();
      })
      .catch((err) => {
        console.error("Failed to export image", err);
      });
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div
        ref={canvasRef}
        className="relative w-[500px] h-[500px] bg-white border-4 border-gray-300 rounded-2xl shadow-xl overflow-hidden"
        onClick={() => setSelected(false)} // Deselect design on canvas click
      >
        <img
          src={baseImage}
          alt="Base"
          className="w-full h-full object-contain absolute"
        />

        {designImage && (
          <Rnd
            size={size}
            position={position}
            onClick={(e) => {
              e.stopPropagation();
              setSelected(true);
            }}
            onDragStop={(e, d) => {
              setPosition({ x: d.x, y: d.y });
            }}
            onResizeStop={(e, direction, ref, delta, pos) => {
              const parentWidth = 500;
              const parentHeight = 500;
              const newWidth = parseInt(ref.style.width);
              const newHeight = parseInt(ref.style.height);

              const minWidth = 0.2 * parentWidth;
              const maxWidth = 0.6 * parentWidth;

              const width = Math.max(minWidth, Math.min(newWidth, maxWidth));
              const height = Math.max(minWidth, Math.min(newHeight, maxWidth));

              setSize({ width, height });
              setPosition(pos);
            }}
            bounds="parent"
            minWidth={100}
            minHeight={100}
            maxWidth={300}
            maxHeight={300}
            style={{
              border: selected ? "2px dotted red" : "none",
              zIndex: 10,
              transition: "all 0.1s ease-in-out",
              cursor: "move",
            }}
          >
            <div className="relative w-full h-full">
              <img
                src={designImage}
                alt="Design"
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "contain",
                  pointerEvents: "none",
                  userSelect: "none",
                }}
              />

              {selected && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm("Remove this design?")) {
                      onRemoveDesign(); // tell parent to reset
                      setSelected(false);
                    }
                  }}
                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600 z-20 shadow-lg"
                >
                  ✖
                </button>
              )}
            </div>
          </Rnd>
        )}
      </div>

      <div className="flex justify-center gap-4 mt-4">
        <button
          onClick={handleDownload}
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition"
        >
          Save Mockup as PNG
        </button>
      </div>
    </div>
  );
}
