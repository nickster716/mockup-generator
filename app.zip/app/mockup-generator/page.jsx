"use client";

import { useState } from "react";
import ImageSelector from "./components/ImageSelector";
import DesignUploader from "./components/DesignUploader";
import CanvasEditor from "./components/CanvasEditor";
import ControlsPanel from "./components/ControlsPanel";

const dummyImages = [
  "https://picsum.photos/id/237/200/300", // fixed dog image
  "https://picsum.photos/id/238/200/300",
  "https://picsum.photos/id/239/200/300",
];

export default function MockupGeneratorPage() {
  const [baseImage, setBaseImage] = useState(dummyImages[0]);
  const [designImage, setDesignImage] = useState(null);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200 p-6">
      <div className="w-full max-w-4xl bg-white/60 backdrop-blur-lg rounded-xl shadow-2xl p-6 space-y-6 border border-white/30">
        <h1 className="text-3xl font-bold text-center text-gray-800">
          Mockup Generator
        </h1>

        <ImageSelector
          images={dummyImages}
          onSelect={setBaseImage}
          selected={baseImage}
        />

        <DesignUploader onUpload={setDesignImage} />

        <CanvasEditor
          baseImage={baseImage}
          designImage={designImage}
          onRemoveDesign={() => setDesignImage(null)}
        />

        <div className="flex justify-center gap-4">
          <ControlsPanel onReset={() => setDesignImage(null)} />
        </div>
      </div>
    </div>
  );
}
